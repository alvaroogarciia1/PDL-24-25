Para la ejecucion del programa habra que colocar el codigo con el fichero fuente que se desea ejecutar en la misma carpeta del fichero PracticaPDL.jar y hacer una de las siguientes opciones:

 - Usuarios Windows y Linux:
 	1. Situese en la terminal y posicionese en la carpeta donde tenga ambos archivos.
 	2. Ejecute el comando <java -jar PracticaPDL.jar> y se le crearán los archivos con los resultados de la ejecución.
 	
 - Usuario Windows opcion 2. Si los dos archivos estan bien colocalos se podrá ejecutar el código haciendo doble clic sobre el .jar. Puede provocar algun error, si es asi probar con la opción 1. 
